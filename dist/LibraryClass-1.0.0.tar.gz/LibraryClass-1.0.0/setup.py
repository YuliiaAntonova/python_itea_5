from setuptools import setup


setup(
    name='LibraryClass',
    version='1.0.0',
    description='A library itea for test',
    author='None',
    author_email='test@test.com',
    packages=['libraryClass', 'libraryClass.library_inits']
)